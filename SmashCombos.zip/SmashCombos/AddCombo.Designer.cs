﻿namespace SmashCombos
{
    partial class AddCombo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddCombo));
            this.btnNair = new System.Windows.Forms.Button();
            this.btnGrab = new System.Windows.Forms.Button();
            this.btnDashAttack = new System.Windows.Forms.Button();
            this.btnDownSmash = new System.Windows.Forms.Button();
            this.btnUpSmash = new System.Windows.Forms.Button();
            this.btnJab = new System.Windows.Forms.Button();
            this.btnFSmash = new System.Windows.Forms.Button();
            this.btnBair = new System.Windows.Forms.Button();
            this.btnFair = new System.Windows.Forms.Button();
            this.btnDair = new System.Windows.Forms.Button();
            this.btnUpAir = new System.Windows.Forms.Button();
            this.btnPummel = new System.Windows.Forms.Button();
            this.btnDashGrab = new System.Windows.Forms.Button();
            this.btnFTilt = new System.Windows.Forms.Button();
            this.btnDTilt = new System.Windows.Forms.Button();
            this.btnUpTilt = new System.Windows.Forms.Button();
            this.btnSideSpecial = new System.Windows.Forms.Button();
            this.btnUpSpecial = new System.Windows.Forms.Button();
            this.btnDownSpecial = new System.Windows.Forms.Button();
            this.btnNeutralSpecial = new System.Windows.Forms.Button();
            this.rtbNotes = new System.Windows.Forms.RichTextBox();
            this.lblCombo = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnUpThrow = new System.Windows.Forms.Button();
            this.btnDownThrow = new System.Windows.Forms.Button();
            this.btnBackThrow = new System.Windows.Forms.Button();
            this.btnFThrow = new System.Windows.Forms.Button();
            this.Opponent = new System.Windows.Forms.Label();
            this.lblDI = new System.Windows.Forms.Label();
            this.lblMinPercent = new System.Windows.Forms.Label();
            this.lblMaxPercent = new System.Windows.Forms.Label();
            this.numMinPercent = new System.Windows.Forms.NumericUpDown();
            this.numMaxPercent = new System.Windows.Forms.NumericUpDown();
            this.lblNote = new System.Windows.Forms.Label();
            this.cbNoneDI = new System.Windows.Forms.CheckBox();
            this.cbUpDI = new System.Windows.Forms.CheckBox();
            this.cbRightDI = new System.Windows.Forms.CheckBox();
            this.cbDownDI = new System.Windows.Forms.CheckBox();
            this.cbLeftDI = new System.Windows.Forms.CheckBox();
            this.btnDeleteLast = new System.Windows.Forms.Button();
            this.btnDeleteCombo = new System.Windows.Forms.Button();
            this.lblOpponent = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numMinPercent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMaxPercent)).BeginInit();
            this.SuspendLayout();
            // 
            // btnNair
            // 
            this.btnNair.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnNair.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNair.Location = new System.Drawing.Point(409, 123);
            this.btnNair.Name = "btnNair";
            this.btnNair.Size = new System.Drawing.Size(84, 31);
            this.btnNair.TabIndex = 0;
            this.btnNair.Text = "Neutral Air";
            this.btnNair.UseVisualStyleBackColor = false;
            this.btnNair.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnGrab
            // 
            this.btnGrab.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnGrab.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGrab.Location = new System.Drawing.Point(753, 12);
            this.btnGrab.Name = "btnGrab";
            this.btnGrab.Size = new System.Drawing.Size(84, 31);
            this.btnGrab.TabIndex = 1;
            this.btnGrab.Text = "Grab";
            this.btnGrab.UseVisualStyleBackColor = false;
            this.btnGrab.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnDashAttack
            // 
            this.btnDashAttack.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDashAttack.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashAttack.Location = new System.Drawing.Point(512, 160);
            this.btnDashAttack.Name = "btnDashAttack";
            this.btnDashAttack.Size = new System.Drawing.Size(107, 31);
            this.btnDashAttack.TabIndex = 2;
            this.btnDashAttack.Text = "Dash Attack";
            this.btnDashAttack.UseVisualStyleBackColor = false;
            this.btnDashAttack.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnDownSmash
            // 
            this.btnDownSmash.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDownSmash.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDownSmash.Location = new System.Drawing.Point(166, 86);
            this.btnDownSmash.Name = "btnDownSmash";
            this.btnDownSmash.Size = new System.Drawing.Size(107, 31);
            this.btnDownSmash.TabIndex = 3;
            this.btnDownSmash.Text = "Down Smash";
            this.btnDownSmash.UseVisualStyleBackColor = false;
            this.btnDownSmash.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnUpSmash
            // 
            this.btnUpSmash.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpSmash.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpSmash.Location = new System.Drawing.Point(166, 49);
            this.btnUpSmash.Name = "btnUpSmash";
            this.btnUpSmash.Size = new System.Drawing.Size(107, 31);
            this.btnUpSmash.TabIndex = 4;
            this.btnUpSmash.Text = "Up Smash";
            this.btnUpSmash.UseVisualStyleBackColor = false;
            this.btnUpSmash.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnJab
            // 
            this.btnJab.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnJab.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJab.Location = new System.Drawing.Point(753, 86);
            this.btnJab.Name = "btnJab";
            this.btnJab.Size = new System.Drawing.Size(84, 31);
            this.btnJab.TabIndex = 5;
            this.btnJab.Text = "Jab";
            this.btnJab.UseVisualStyleBackColor = false;
            this.btnJab.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnFSmash
            // 
            this.btnFSmash.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnFSmash.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFSmash.Location = new System.Drawing.Point(166, 12);
            this.btnFSmash.Name = "btnFSmash";
            this.btnFSmash.Size = new System.Drawing.Size(107, 31);
            this.btnFSmash.TabIndex = 6;
            this.btnFSmash.Text = "Forward Smash";
            this.btnFSmash.UseVisualStyleBackColor = false;
            this.btnFSmash.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnBair
            // 
            this.btnBair.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBair.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBair.Location = new System.Drawing.Point(409, 160);
            this.btnBair.Name = "btnBair";
            this.btnBair.Size = new System.Drawing.Size(84, 31);
            this.btnBair.TabIndex = 7;
            this.btnBair.Text = "Back Air";
            this.btnBair.UseVisualStyleBackColor = false;
            this.btnBair.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnFair
            // 
            this.btnFair.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnFair.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFair.Location = new System.Drawing.Point(409, 12);
            this.btnFair.Name = "btnFair";
            this.btnFair.Size = new System.Drawing.Size(84, 31);
            this.btnFair.TabIndex = 8;
            this.btnFair.Text = "Forward Air";
            this.btnFair.UseVisualStyleBackColor = false;
            this.btnFair.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnDair
            // 
            this.btnDair.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDair.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDair.Location = new System.Drawing.Point(409, 86);
            this.btnDair.Name = "btnDair";
            this.btnDair.Size = new System.Drawing.Size(84, 31);
            this.btnDair.TabIndex = 9;
            this.btnDair.Text = "Down Air";
            this.btnDair.UseVisualStyleBackColor = false;
            this.btnDair.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnUpAir
            // 
            this.btnUpAir.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpAir.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpAir.Location = new System.Drawing.Point(409, 49);
            this.btnUpAir.Name = "btnUpAir";
            this.btnUpAir.Size = new System.Drawing.Size(84, 31);
            this.btnUpAir.TabIndex = 10;
            this.btnUpAir.Text = "Up Air";
            this.btnUpAir.UseVisualStyleBackColor = false;
            this.btnUpAir.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnPummel
            // 
            this.btnPummel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPummel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPummel.Location = new System.Drawing.Point(753, 49);
            this.btnPummel.Name = "btnPummel";
            this.btnPummel.Size = new System.Drawing.Size(84, 31);
            this.btnPummel.TabIndex = 11;
            this.btnPummel.Text = "Pummel";
            this.btnPummel.UseVisualStyleBackColor = false;
            this.btnPummel.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnDashGrab
            // 
            this.btnDashGrab.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDashGrab.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashGrab.Location = new System.Drawing.Point(635, 160);
            this.btnDashGrab.Name = "btnDashGrab";
            this.btnDashGrab.Size = new System.Drawing.Size(101, 31);
            this.btnDashGrab.TabIndex = 12;
            this.btnDashGrab.Text = "Dash Grab";
            this.btnDashGrab.UseVisualStyleBackColor = false;
            this.btnDashGrab.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnFTilt
            // 
            this.btnFTilt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnFTilt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFTilt.Location = new System.Drawing.Point(297, 12);
            this.btnFTilt.Name = "btnFTilt";
            this.btnFTilt.Size = new System.Drawing.Size(92, 31);
            this.btnFTilt.TabIndex = 13;
            this.btnFTilt.Text = "Forward Tilt";
            this.btnFTilt.UseVisualStyleBackColor = false;
            this.btnFTilt.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnDTilt
            // 
            this.btnDTilt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDTilt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDTilt.Location = new System.Drawing.Point(297, 86);
            this.btnDTilt.Name = "btnDTilt";
            this.btnDTilt.Size = new System.Drawing.Size(92, 31);
            this.btnDTilt.TabIndex = 14;
            this.btnDTilt.Text = "Down Tilt";
            this.btnDTilt.UseVisualStyleBackColor = false;
            this.btnDTilt.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnUpTilt
            // 
            this.btnUpTilt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpTilt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpTilt.Location = new System.Drawing.Point(297, 49);
            this.btnUpTilt.Name = "btnUpTilt";
            this.btnUpTilt.Size = new System.Drawing.Size(92, 31);
            this.btnUpTilt.TabIndex = 15;
            this.btnUpTilt.Text = "Up Tilt";
            this.btnUpTilt.UseVisualStyleBackColor = false;
            this.btnUpTilt.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnSideSpecial
            // 
            this.btnSideSpecial.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSideSpecial.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSideSpecial.Location = new System.Drawing.Point(512, 12);
            this.btnSideSpecial.Name = "btnSideSpecial";
            this.btnSideSpecial.Size = new System.Drawing.Size(107, 31);
            this.btnSideSpecial.TabIndex = 16;
            this.btnSideSpecial.Text = "Side Special";
            this.btnSideSpecial.UseVisualStyleBackColor = false;
            this.btnSideSpecial.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnUpSpecial
            // 
            this.btnUpSpecial.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpSpecial.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpSpecial.Location = new System.Drawing.Point(512, 49);
            this.btnUpSpecial.Name = "btnUpSpecial";
            this.btnUpSpecial.Size = new System.Drawing.Size(107, 31);
            this.btnUpSpecial.TabIndex = 17;
            this.btnUpSpecial.Text = "Up Special";
            this.btnUpSpecial.UseVisualStyleBackColor = false;
            this.btnUpSpecial.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnDownSpecial
            // 
            this.btnDownSpecial.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDownSpecial.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDownSpecial.Location = new System.Drawing.Point(512, 86);
            this.btnDownSpecial.Name = "btnDownSpecial";
            this.btnDownSpecial.Size = new System.Drawing.Size(107, 31);
            this.btnDownSpecial.TabIndex = 18;
            this.btnDownSpecial.Text = "Down Special";
            this.btnDownSpecial.UseVisualStyleBackColor = false;
            this.btnDownSpecial.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnNeutralSpecial
            // 
            this.btnNeutralSpecial.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnNeutralSpecial.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNeutralSpecial.Location = new System.Drawing.Point(512, 123);
            this.btnNeutralSpecial.Name = "btnNeutralSpecial";
            this.btnNeutralSpecial.Size = new System.Drawing.Size(107, 31);
            this.btnNeutralSpecial.TabIndex = 19;
            this.btnNeutralSpecial.Text = "Neutral Special";
            this.btnNeutralSpecial.UseVisualStyleBackColor = false;
            this.btnNeutralSpecial.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // rtbNotes
            // 
            this.rtbNotes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.rtbNotes.Location = new System.Drawing.Point(12, 274);
            this.rtbNotes.Name = "rtbNotes";
            this.rtbNotes.Size = new System.Drawing.Size(825, 98);
            this.rtbNotes.TabIndex = 21;
            this.rtbNotes.Text = "";
            // 
            // lblCombo
            // 
            this.lblCombo.AutoSize = true;
            this.lblCombo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCombo.Location = new System.Drawing.Point(15, 217);
            this.lblCombo.Name = "lblCombo";
            this.lblCombo.Size = new System.Drawing.Size(392, 20);
            this.lblCombo.TabIndex = 22;
            this.lblCombo.Text = "Dash Attack -> Up Tilt -> Up Air -> Up Air -> Neutral Air";
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(732, 237);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(105, 31);
            this.btnSave.TabIndex = 25;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnUpThrow
            // 
            this.btnUpThrow.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpThrow.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpThrow.Location = new System.Drawing.Point(635, 49);
            this.btnUpThrow.Name = "btnUpThrow";
            this.btnUpThrow.Size = new System.Drawing.Size(101, 31);
            this.btnUpThrow.TabIndex = 29;
            this.btnUpThrow.Text = "Up Throw";
            this.btnUpThrow.UseVisualStyleBackColor = false;
            this.btnUpThrow.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnDownThrow
            // 
            this.btnDownThrow.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDownThrow.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDownThrow.Location = new System.Drawing.Point(635, 86);
            this.btnDownThrow.Name = "btnDownThrow";
            this.btnDownThrow.Size = new System.Drawing.Size(101, 31);
            this.btnDownThrow.TabIndex = 28;
            this.btnDownThrow.Text = "Down Throw";
            this.btnDownThrow.UseVisualStyleBackColor = false;
            this.btnDownThrow.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnBackThrow
            // 
            this.btnBackThrow.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBackThrow.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackThrow.Location = new System.Drawing.Point(635, 123);
            this.btnBackThrow.Name = "btnBackThrow";
            this.btnBackThrow.Size = new System.Drawing.Size(101, 31);
            this.btnBackThrow.TabIndex = 27;
            this.btnBackThrow.Text = "Back Throw";
            this.btnBackThrow.UseVisualStyleBackColor = false;
            this.btnBackThrow.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // btnFThrow
            // 
            this.btnFThrow.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnFThrow.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFThrow.Location = new System.Drawing.Point(635, 12);
            this.btnFThrow.Name = "btnFThrow";
            this.btnFThrow.Size = new System.Drawing.Size(101, 31);
            this.btnFThrow.TabIndex = 26;
            this.btnFThrow.Text = "Forward Throw";
            this.btnFThrow.UseVisualStyleBackColor = false;
            this.btnFThrow.Click += new System.EventHandler(this.btn_MoveClick);
            // 
            // Opponent
            // 
            this.Opponent.AutoSize = true;
            this.Opponent.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Opponent.Location = new System.Drawing.Point(9, 9);
            this.Opponent.Name = "Opponent";
            this.Opponent.Size = new System.Drawing.Size(79, 17);
            this.Opponent.TabIndex = 30;
            this.Opponent.Text = "Opponent";
            // 
            // lblDI
            // 
            this.lblDI.AutoSize = true;
            this.lblDI.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDI.Location = new System.Drawing.Point(9, 86);
            this.lblDI.Name = "lblDI";
            this.lblDI.Size = new System.Drawing.Size(23, 17);
            this.lblDI.TabIndex = 31;
            this.lblDI.Text = "DI";
            // 
            // lblMinPercent
            // 
            this.lblMinPercent.AutoSize = true;
            this.lblMinPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMinPercent.Location = new System.Drawing.Point(163, 144);
            this.lblMinPercent.Name = "lblMinPercent";
            this.lblMinPercent.Size = new System.Drawing.Size(83, 17);
            this.lblMinPercent.TabIndex = 33;
            this.lblMinPercent.Text = "Min Percent";
            // 
            // lblMaxPercent
            // 
            this.lblMaxPercent.AutoSize = true;
            this.lblMaxPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaxPercent.Location = new System.Drawing.Point(294, 144);
            this.lblMaxPercent.Name = "lblMaxPercent";
            this.lblMaxPercent.Size = new System.Drawing.Size(86, 17);
            this.lblMaxPercent.TabIndex = 34;
            this.lblMaxPercent.Text = "Max Percent";
            // 
            // numMinPercent
            // 
            this.numMinPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numMinPercent.Location = new System.Drawing.Point(166, 166);
            this.numMinPercent.Name = "numMinPercent";
            this.numMinPercent.Size = new System.Drawing.Size(80, 22);
            this.numMinPercent.TabIndex = 35;
            // 
            // numMaxPercent
            // 
            this.numMaxPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numMaxPercent.Location = new System.Drawing.Point(297, 166);
            this.numMaxPercent.Name = "numMaxPercent";
            this.numMaxPercent.Size = new System.Drawing.Size(80, 22);
            this.numMaxPercent.TabIndex = 36;
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNote.Location = new System.Drawing.Point(9, 251);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(38, 17);
            this.lblNote.TabIndex = 37;
            this.lblNote.Text = "Note";
            // 
            // cbNoneDI
            // 
            this.cbNoneDI.AutoSize = true;
            this.cbNoneDI.Checked = true;
            this.cbNoneDI.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbNoneDI.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cbNoneDI.Location = new System.Drawing.Point(12, 169);
            this.cbNoneDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbNoneDI.Name = "cbNoneDI";
            this.cbNoneDI.Size = new System.Drawing.Size(61, 23);
            this.cbNoneDI.TabIndex = 43;
            this.cbNoneDI.Text = "None";
            this.cbNoneDI.UseVisualStyleBackColor = true;
            // 
            // cbUpDI
            // 
            this.cbUpDI.AutoSize = true;
            this.cbUpDI.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cbUpDI.Location = new System.Drawing.Point(12, 143);
            this.cbUpDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbUpDI.Name = "cbUpDI";
            this.cbUpDI.Size = new System.Drawing.Size(46, 23);
            this.cbUpDI.TabIndex = 39;
            this.cbUpDI.Text = "Up";
            this.cbUpDI.UseVisualStyleBackColor = true;
            // 
            // cbRightDI
            // 
            this.cbRightDI.AutoSize = true;
            this.cbRightDI.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cbRightDI.Location = new System.Drawing.Point(77, 116);
            this.cbRightDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbRightDI.Name = "cbRightDI";
            this.cbRightDI.Size = new System.Drawing.Size(60, 23);
            this.cbRightDI.TabIndex = 42;
            this.cbRightDI.Text = "Right";
            this.cbRightDI.UseVisualStyleBackColor = true;
            // 
            // cbDownDI
            // 
            this.cbDownDI.AutoSize = true;
            this.cbDownDI.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cbDownDI.Location = new System.Drawing.Point(77, 143);
            this.cbDownDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbDownDI.Name = "cbDownDI";
            this.cbDownDI.Size = new System.Drawing.Size(64, 23);
            this.cbDownDI.TabIndex = 40;
            this.cbDownDI.Text = "Down";
            this.cbDownDI.UseVisualStyleBackColor = true;
            // 
            // cbLeftDI
            // 
            this.cbLeftDI.AutoSize = true;
            this.cbLeftDI.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cbLeftDI.Location = new System.Drawing.Point(12, 116);
            this.cbLeftDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbLeftDI.Name = "cbLeftDI";
            this.cbLeftDI.Size = new System.Drawing.Size(51, 23);
            this.cbLeftDI.TabIndex = 41;
            this.cbLeftDI.Text = "Left";
            this.cbLeftDI.UseVisualStyleBackColor = true;
            // 
            // btnDeleteLast
            // 
            this.btnDeleteLast.BackColor = System.Drawing.Color.Red;
            this.btnDeleteLast.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteLast.Location = new System.Drawing.Point(753, 123);
            this.btnDeleteLast.Name = "btnDeleteLast";
            this.btnDeleteLast.Size = new System.Drawing.Size(84, 65);
            this.btnDeleteLast.TabIndex = 44;
            this.btnDeleteLast.Text = "Delete Last";
            this.btnDeleteLast.UseVisualStyleBackColor = false;
            this.btnDeleteLast.Click += new System.EventHandler(this.btnDeleteLast_Click);
            // 
            // btnDeleteCombo
            // 
            this.btnDeleteCombo.BackColor = System.Drawing.Color.Red;
            this.btnDeleteCombo.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteCombo.Location = new System.Drawing.Point(608, 237);
            this.btnDeleteCombo.Name = "btnDeleteCombo";
            this.btnDeleteCombo.Size = new System.Drawing.Size(118, 31);
            this.btnDeleteCombo.TabIndex = 46;
            this.btnDeleteCombo.Text = "Delete Combo";
            this.btnDeleteCombo.UseVisualStyleBackColor = false;
            this.btnDeleteCombo.Visible = false;
            this.btnDeleteCombo.Click += new System.EventHandler(this.btnDeleteCombo_Click);
            // 
            // lblOpponent
            // 
            this.lblOpponent.AutoSize = true;
            this.lblOpponent.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.lblOpponent.Location = new System.Drawing.Point(9, 38);
            this.lblOpponent.Name = "lblOpponent";
            this.lblOpponent.Size = new System.Drawing.Size(45, 18);
            this.lblOpponent.TabIndex = 47;
            this.lblOpponent.Text = "Falco";
            // 
            // AddCombo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(846, 384);
            this.Controls.Add(this.lblOpponent);
            this.Controls.Add(this.btnDeleteCombo);
            this.Controls.Add(this.btnDeleteLast);
            this.Controls.Add(this.cbNoneDI);
            this.Controls.Add(this.cbUpDI);
            this.Controls.Add(this.cbRightDI);
            this.Controls.Add(this.cbDownDI);
            this.Controls.Add(this.cbLeftDI);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.numMaxPercent);
            this.Controls.Add(this.numMinPercent);
            this.Controls.Add(this.lblMaxPercent);
            this.Controls.Add(this.lblMinPercent);
            this.Controls.Add(this.lblDI);
            this.Controls.Add(this.Opponent);
            this.Controls.Add(this.btnUpThrow);
            this.Controls.Add(this.btnDownThrow);
            this.Controls.Add(this.btnBackThrow);
            this.Controls.Add(this.btnFThrow);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblCombo);
            this.Controls.Add(this.rtbNotes);
            this.Controls.Add(this.btnNeutralSpecial);
            this.Controls.Add(this.btnDownSpecial);
            this.Controls.Add(this.btnUpSpecial);
            this.Controls.Add(this.btnSideSpecial);
            this.Controls.Add(this.btnUpTilt);
            this.Controls.Add(this.btnDTilt);
            this.Controls.Add(this.btnFTilt);
            this.Controls.Add(this.btnDashGrab);
            this.Controls.Add(this.btnPummel);
            this.Controls.Add(this.btnUpAir);
            this.Controls.Add(this.btnDair);
            this.Controls.Add(this.btnFair);
            this.Controls.Add(this.btnBair);
            this.Controls.Add(this.btnFSmash);
            this.Controls.Add(this.btnJab);
            this.Controls.Add(this.btnUpSmash);
            this.Controls.Add(this.btnDownSmash);
            this.Controls.Add(this.btnDashAttack);
            this.Controls.Add(this.btnGrab);
            this.Controls.Add(this.btnNair);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddCombo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Combo";
            ((System.ComponentModel.ISupportInitialize)(this.numMinPercent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMaxPercent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNair;
        private System.Windows.Forms.Button btnGrab;
        private System.Windows.Forms.Button btnDashAttack;
        private System.Windows.Forms.Button btnDownSmash;
        private System.Windows.Forms.Button btnUpSmash;
        private System.Windows.Forms.Button btnJab;
        private System.Windows.Forms.Button btnFSmash;
        private System.Windows.Forms.Button btnBair;
        private System.Windows.Forms.Button btnFair;
        private System.Windows.Forms.Button btnDair;
        private System.Windows.Forms.Button btnUpAir;
        private System.Windows.Forms.Button btnPummel;
        private System.Windows.Forms.Button btnDashGrab;
        private System.Windows.Forms.Button btnFTilt;
        private System.Windows.Forms.Button btnDTilt;
        private System.Windows.Forms.Button btnUpTilt;
        private System.Windows.Forms.Button btnSideSpecial;
        private System.Windows.Forms.Button btnUpSpecial;
        private System.Windows.Forms.Button btnDownSpecial;
        private System.Windows.Forms.Button btnNeutralSpecial;
        private System.Windows.Forms.RichTextBox rtbNotes;
        private System.Windows.Forms.Label lblCombo;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnUpThrow;
        private System.Windows.Forms.Button btnDownThrow;
        private System.Windows.Forms.Button btnBackThrow;
        private System.Windows.Forms.Button btnFThrow;
        private System.Windows.Forms.Label Opponent;
        private System.Windows.Forms.Label lblDI;
        private System.Windows.Forms.Label lblMinPercent;
        private System.Windows.Forms.Label lblMaxPercent;
        private System.Windows.Forms.NumericUpDown numMinPercent;
        private System.Windows.Forms.NumericUpDown numMaxPercent;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.CheckBox cbNoneDI;
        private System.Windows.Forms.CheckBox cbUpDI;
        private System.Windows.Forms.CheckBox cbRightDI;
        private System.Windows.Forms.CheckBox cbDownDI;
        private System.Windows.Forms.CheckBox cbLeftDI;
        private System.Windows.Forms.Button btnDeleteLast;
        private System.Windows.Forms.Button btnDeleteCombo;
        private System.Windows.Forms.Label lblOpponent;
    }
}