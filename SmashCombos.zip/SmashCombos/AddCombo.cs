﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;

namespace SmashCombos
{
    public partial class AddCombo : Form
    {
        public List<ComboMoves> Moves;
        public int MinPercent { get; set; }
        public int MaxPercent { get; set; }
        public List<DI> ValidDI { get; set; }
        public string Note { get; set; }
        public string CharacterName { get; set; }

        public AddCombo(string opponent)
        {
            InitializeComponent();

            Moves = new List<ComboMoves>();
            lblCombo.Text = "";

            SetupTags();

            lblOpponent.Text = opponent;
        }

        public AddCombo(List<ComboMoves> moves, string characterName, int minPercent, int maxPercent, List<DI> di, string note)
        {
            Moves = moves;
            MinPercent = minPercent;
            MaxPercent = maxPercent;
            ValidDI = di;
            Note = note;

            InitializeComponent();
            btnDeleteCombo.Visible = true;

            SetupTags();

            lblOpponent.Text = characterName;
            lblCombo.Text = GetComboString();
            rtbNotes.Text = Note;
            numMinPercent.Value = minPercent;
            numMaxPercent.Value = maxPercent;

            foreach(DI d in di)
            {
                if (d == DI.Up)
                    cbUpDI.Checked = true;
                if (d == DI.Down)
                    cbDownDI.Checked = true;
                if (d == DI.Left)
                    cbLeftDI.Checked = true;
                if (d == DI.Right)
                    cbRightDI.Checked = true;
                if (d == DI.None)
                    cbNoneDI.Checked = true;
            }
        }

        private void SetupTags()
        {
            btnFSmash.Tag = ComboMoves.ForwardSmash;
            btnUpSmash.Tag = ComboMoves.UpSmash;
            btnDownSmash.Tag = ComboMoves.DownSmash;
            btnFTilt.Tag = ComboMoves.ForwardTilt;
            btnUpTilt.Tag = ComboMoves.UpTilt;
            btnDTilt.Tag = ComboMoves.DownTilt;
            btnFair.Tag = ComboMoves.ForwardAir;
            btnUpAir.Tag = ComboMoves.UpAir;
            btnDair.Tag = ComboMoves.DownAir;
            btnNair.Tag = ComboMoves.NeutralAir;
            btnBair.Tag = ComboMoves.BackAir;
            btnSideSpecial.Tag = ComboMoves.SideSpecial;
            btnUpSpecial.Tag = ComboMoves.UpSpecial;
            btnDownSpecial.Tag = ComboMoves.DownSpecial;
            btnNeutralSpecial.Tag = ComboMoves.NeutralSpecial;
            btnFThrow.Tag = ComboMoves.ForwardThrow;
            btnUpThrow.Tag = ComboMoves.UpThrow;
            btnDownThrow.Tag = ComboMoves.DownThrow;
            btnBackThrow.Tag = ComboMoves.BackThrow;
            btnGrab.Tag = ComboMoves.Grab;
            btnPummel.Tag = ComboMoves.Pummel;
            btnJab.Tag = ComboMoves.Jab;
            btnDashGrab.Tag = ComboMoves.DashGrab;
            btnDashAttack.Tag = ComboMoves.DashAttack;
        }

        private void btn_MoveClick(object sender, EventArgs e)
        {
            ComboMoves move = (ComboMoves)((Button)sender).Tag;

            if (lblCombo.Text.Length > 0)
            {
                lblCombo.Text += " -> ";
            }

            lblCombo.Text += HelperMethods.GetMoveTitle(move);
            Moves.Add(move);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            MinPercent = (int)numMinPercent.Value;
            MaxPercent = (int)numMaxPercent.Value;
            ValidDI = new List<DI>();
            Note = rtbNotes.Text;

            if (cbNoneDI.Checked)
                ValidDI.Add(DI.None);
            if (cbLeftDI.Checked)
                ValidDI.Add(DI.Left);
            if (cbRightDI.Checked)
                ValidDI.Add(DI.Right);
            if (cbUpDI.Checked)
                ValidDI.Add(DI.Up);
            if (cbDownDI.Checked)
                ValidDI.Add(DI.Down);

            DialogResult = DialogResult.OK;
        }

        private void btnDeleteLast_Click(object sender, EventArgs e)
        {
            int index = Moves.Count - 1;

            if (index < 0)
            {
                return;
            }

            Moves.RemoveAt(index);

            lblCombo.Text = GetComboString();
        }

        public string GetComboString()
        {
            int lastIndex = Moves.Count - 1;

            if (lastIndex < 0)
            {
                return "";
            }

            string ret = "";

            for (int i = 0; i < lastIndex; i++)
            {
                ComboMoves move = Moves[i];
                ret += HelperMethods.GetMoveTitle(move) + " -> ";
            }

            ret += Moves[lastIndex].ToString();

            return ret;
        }

        private void btnDeleteCombo_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Really delete combo?", "Delete Combo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                DialogResult = DialogResult.No;
            }
        }
    }
}