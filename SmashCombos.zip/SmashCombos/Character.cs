﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SmashCombos
{
    public class Character
    {
        public string Name { get; set; }
        public List<Combo> Combos { get; set; }
        public CharacterAttributes Attributes { get; set; }
    }
}