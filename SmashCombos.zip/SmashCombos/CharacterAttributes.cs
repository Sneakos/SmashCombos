﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmashCombos
{
    public class CharacterAttributes
    {
        public double Weight { get; set; }
        public double Gravity { get; set; }
        public double WalkSpeed { get; set; }
        public double RunSpeed { get; set; }
        public double InitialDash { get; set; }
        public double AirSpeed { get; set; }
        public double FallSpeed { get; set; }
        public double FastFallSpeed { get; set; }
        public int SH { get; set; }
        public int FH { get; set; }
        public int SHFF { get; set; }
        public int FHFF { get; set; }
        public Tuple<ComboMoves, int> OOS1 { get; set; }
        public Tuple<ComboMoves, int> OOS2 { get; set; }
        public Tuple<ComboMoves, int> OOS3 { get; set; }
        public int ShieldGrab { get; set; }
    }
}
