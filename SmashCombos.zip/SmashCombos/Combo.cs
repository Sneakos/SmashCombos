﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmashCombos
{


    public class Combo
    {
        public ComboMoves[] Moves { get; set; }
        public int LowPercent { get; set; }
        public int HighPercent { get; set; }
        public DI[] DIs { get; set; }
        public string Note { get; set; }
    }
}
