﻿namespace SmashCombos
{
    public enum DI
    {
        Up = 0,
        Down = 1,
        Left = 2,
        Right = 3,
        None = 4
    }

    public enum ComboMoves
    {
        ForwardSmash = 0,
        UpSmash = 1,
        DownSmash = 2,
        ForwardTilt = 3,
        UpTilt = 4,
        DownTilt = 5,
        ForwardAir = 6,
        UpAir = 7,
        DownAir = 8,
        NeutralAir = 9,
        BackAir = 10,
        SideSpecial = 11,
        UpSpecial = 12,
        DownSpecial = 13,
        NeutralSpecial = 14,
        ForwardThrow = 15,
        UpThrow = 16,
        DownThrow = 17,
        BackThrow =18,
        Grab = 19,
        Pummel = 20,
        Jab = 21,
        DashGrab = 22,
        DashAttack = 23,
    }

    public enum Game
    {
        Melee,
        Ultimate,
        Rivals
    }
}
