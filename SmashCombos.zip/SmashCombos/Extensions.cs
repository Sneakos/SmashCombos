﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Windows.Forms.VisualStyles;

namespace SmashCombos
{
    public static class Extensions
    {
        public static void AlignLabelToScreen(this Label lbl, HorizontalAlignment horizontalAlignment, VerticalAlignment verticalAlignment)
        {
            Control parent = lbl.Parent;

            int lblLength = lbl.Width;
            int lblHeight = lbl.Height;

            Point point = new Point();

            switch (horizontalAlignment)
            {
                case HorizontalAlignment.Left:
                    point.X = 3;
                    break;
                case HorizontalAlignment.Right:
                    point.X = parent.Width - lblLength - 3;
                    break;
                case HorizontalAlignment.Center:
                    point.X = (parent.Width / 2) - (lblLength / 2);
                    break;
            }

            switch (verticalAlignment)
            {
                case VerticalAlignment.Top:
                    point.Y = 3;
                    break;
                case VerticalAlignment.Center:
                    point.Y = (parent.Height / 2) - (lblHeight / 2);
                    break;
                case VerticalAlignment.Bottom:
                    point.Y = parent.Height - 3;
                    break;
            }

            lbl.Location = point;
        }

        public static void AlignLabelToScreenHorizontally(this Label lbl, HorizontalAlignment horizontalAlignment)
        {
            Control parent = lbl.Parent;

            int lblLength = lbl.Width;
            int lblHeight = lbl.Height;

            Point point = new Point(0, lbl.Location.Y);

            switch (horizontalAlignment)
            {
                case HorizontalAlignment.Left:
                    point.X = 5;
                    break;
                case HorizontalAlignment.Right:
                    point.X = parent.Width - lblLength - 25;
                    break;
                case HorizontalAlignment.Center:
                    point.X = (parent.Width / 2) - (lblLength / 2);
                    break;
            }

            lbl.Location = point;
        }

        public static void AlignLabelToScreenVertically(this Label lbl, VerticalAlignment verticalAlignment)
        {
            Control parent = lbl.Parent;

            int lblLength = lbl.Width;
            int lblHeight = lbl.Height;

            Point point = new Point(lbl.Location.X, 0);

            switch (verticalAlignment)
            {
                case VerticalAlignment.Top:
                    point.Y = 5;
                    break;
                case VerticalAlignment.Center:
                    point.Y = (parent.Height / 2) - (lblHeight / 2);
                    break;
                case VerticalAlignment.Bottom:
                    point.Y = parent.Height - lblHeight - 50;
                    break;
            }

            lbl.Location = point;
        }
    }
}
