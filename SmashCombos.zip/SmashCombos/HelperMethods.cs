﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmashCombos
{
    public static class HelperMethods
    {
        public static string Path
        {
            get
            {
#if DEBUG
                return @"..\..";
#else           
                return @"..\..";
#endif
            }
        }

        public static string GetMoveTitle(ComboMoves move)
        {
            switch (move)
            {
                case ComboMoves.ForwardSmash: return "Forward Smash";
                case ComboMoves.UpSmash: return "Up Smash";
                case ComboMoves.DownSmash: return "Down Smash";
                case ComboMoves.ForwardTilt: return "Forward Tilt";
                case ComboMoves.UpTilt: return "Up Tilt";
                case ComboMoves.DownTilt: return "Down Tilt";
                case ComboMoves.ForwardAir: return "Forward Air";
                case ComboMoves.UpAir: return "Up Air";
                case ComboMoves.DownAir: return "Down Air";
                case ComboMoves.NeutralAir: return "Neutral Air";
                case ComboMoves.BackAir: return "Back Air";
                case ComboMoves.SideSpecial: return "Side Special";
                case ComboMoves.UpSpecial: return "Up Special";
                case ComboMoves.DownSpecial: return "Down Special";
                case ComboMoves.NeutralSpecial: return "Neutral Special";
                case ComboMoves.ForwardThrow: return "Forward Throw";
                case ComboMoves.UpThrow: return "Up Throw";
                case ComboMoves.DownThrow: return "Down Throw";
                case ComboMoves.BackThrow: return "Back Throw";
                case ComboMoves.DashGrab: return "Dash Grab";
                case ComboMoves.DashAttack: return "Dash Attack";
                default: return move.ToString();
            }
        }

        public static Bitmap ResizeImage(Image img, Size size)
        {
            var destRect = new Rectangle(0, 0, size.Width, size.Height);
            var destImage = new Bitmap(size.Width, size.Height);

            destImage.SetResolution(img.HorizontalResolution, img.VerticalResolution);

            using (var graphics = Graphics.FromImage(destImage))
            {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

                using (var wrapMode = new ImageAttributes())
                {
                    wrapMode.SetWrapMode(WrapMode.TileFlipXY);
                    graphics.DrawImage(img, destRect, 0, 0, img.Width, img.Height, GraphicsUnit.Pixel, wrapMode);
                }
            }
            return destImage;
        }

        public static Icon IconFromImage(Image img)
        {
            //https://en.wikipedia.org/wiki/ICO_(file_format)
            Icon ico;

            using (MemoryStream ms = new MemoryStream())
            {
                BinaryWriter bw = new BinaryWriter(ms);
                // Header
                bw.Write((short)0);   // 0 : reserved
                bw.Write((short)1);   // 2 : 1=ico, 2=cur
                bw.Write((short)1);   // 4 : number of images
                                      // Image directory
                var w = img.Width;
                if (w >= 256) w = 0;
                bw.Write((byte)w);    // 0 : width of image
                var h = img.Height;
                if (h >= 256) h = 0;
                bw.Write((byte)h);    // 1 : height of image
                bw.Write((byte)0);    // 2 : number of colors in palette
                bw.Write((byte)0);    // 3 : reserved
                bw.Write((short)0);   // 4 : number of color planes
                bw.Write((short)32);   // 6 : bits per pixel
                var sizeHere = ms.Position;
                bw.Write(0);            // 8 : image size
                var start = (int)ms.Position + 4;
                bw.Write(start);      // 12: offset of image data
                                      // Image data

                img.Save(ms, ImageFormat.Png);

                var imageSize = (int)ms.Position - start;
                ms.Seek(sizeHere, SeekOrigin.Begin);
                bw.Write(imageSize);
                ms.Seek(0, SeekOrigin.Begin);

                ico = new Icon(ms);
            }

            return ico;
        }
    }
}