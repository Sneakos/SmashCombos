﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmashCombos
{
    public class Info
    {
        public string Information { get; set; }
        public int Low { get; set; }
        public int High { get; set; }

        public Info(string info, int low, int high)
        {
            Information = info;
            Low = low;
            High = high;
        }
    }
}
