﻿namespace SmashCombos
{
    partial class MatchupChart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MatchupChart));
            this.tbPercentage = new System.Windows.Forms.TrackBar();
            this.cbNoneDI = new System.Windows.Forms.CheckBox();
            this.cbUpDI = new System.Windows.Forms.CheckBox();
            this.cbDownDI = new System.Windows.Forms.CheckBox();
            this.cbLeftDI = new System.Windows.Forms.CheckBox();
            this.cbRightDI = new System.Windows.Forms.CheckBox();
            this.cbAllDI = new System.Windows.Forms.CheckBox();
            this.lblCombos = new System.Windows.Forms.Label();
            this.lblPercentDisplay = new System.Windows.Forms.Label();
            this.btnAddCombo = new System.Windows.Forms.Button();
            this.lblCharacterName = new System.Windows.Forms.Label();
            this.gridCombos = new System.Windows.Forms.DataGridView();
            this.btnGoBack = new System.Windows.Forms.Button();
            this.cbAllPercents = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.tbPercentage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridCombos)).BeginInit();
            this.SuspendLayout();
            // 
            // tbPercentage
            // 
            this.tbPercentage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbPercentage.BackColor = System.Drawing.Color.White;
            this.tbPercentage.Location = new System.Drawing.Point(12, 58);
            this.tbPercentage.Margin = new System.Windows.Forms.Padding(2);
            this.tbPercentage.Maximum = 150;
            this.tbPercentage.Name = "tbPercentage";
            this.tbPercentage.Size = new System.Drawing.Size(894, 45);
            this.tbPercentage.TabIndex = 2;
            this.tbPercentage.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbPercentage.ValueChanged += new System.EventHandler(this.tbPercentage_ValueChanged);
            // 
            // cbNoneDI
            // 
            this.cbNoneDI.AutoSize = true;
            this.cbNoneDI.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.cbNoneDI.Location = new System.Drawing.Point(402, 116);
            this.cbNoneDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbNoneDI.Name = "cbNoneDI";
            this.cbNoneDI.Size = new System.Drawing.Size(67, 24);
            this.cbNoneDI.TabIndex = 11;
            this.cbNoneDI.Text = "No DI";
            this.cbNoneDI.UseVisualStyleBackColor = true;
            this.cbNoneDI.CheckedChanged += new System.EventHandler(this.cbDI_CheckedChanged);
            // 
            // cbUpDI
            // 
            this.cbUpDI.AutoSize = true;
            this.cbUpDI.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.cbUpDI.Location = new System.Drawing.Point(329, 116);
            this.cbUpDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbUpDI.Name = "cbUpDI";
            this.cbUpDI.Size = new System.Drawing.Size(66, 24);
            this.cbUpDI.TabIndex = 7;
            this.cbUpDI.Text = "Up DI";
            this.cbUpDI.UseVisualStyleBackColor = true;
            this.cbUpDI.Click += new System.EventHandler(this.cbDI_CheckedChanged);
            // 
            // cbDownDI
            // 
            this.cbDownDI.AutoSize = true;
            this.cbDownDI.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.cbDownDI.Location = new System.Drawing.Point(238, 116);
            this.cbDownDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbDownDI.Name = "cbDownDI";
            this.cbDownDI.Size = new System.Drawing.Size(86, 24);
            this.cbDownDI.TabIndex = 8;
            this.cbDownDI.Text = "Down DI";
            this.cbDownDI.UseVisualStyleBackColor = true;
            this.cbDownDI.Click += new System.EventHandler(this.cbDI_CheckedChanged);
            // 
            // cbLeftDI
            // 
            this.cbLeftDI.AutoSize = true;
            this.cbLeftDI.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.cbLeftDI.Location = new System.Drawing.Point(154, 116);
            this.cbLeftDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbLeftDI.Name = "cbLeftDI";
            this.cbLeftDI.Size = new System.Drawing.Size(72, 24);
            this.cbLeftDI.TabIndex = 9;
            this.cbLeftDI.Text = "Left DI";
            this.cbLeftDI.UseVisualStyleBackColor = true;
            this.cbLeftDI.Click += new System.EventHandler(this.cbDI_CheckedChanged);
            // 
            // cbRightDI
            // 
            this.cbRightDI.AutoSize = true;
            this.cbRightDI.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.cbRightDI.Location = new System.Drawing.Point(66, 116);
            this.cbRightDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbRightDI.Name = "cbRightDI";
            this.cbRightDI.Size = new System.Drawing.Size(82, 24);
            this.cbRightDI.TabIndex = 10;
            this.cbRightDI.Text = "Right DI";
            this.cbRightDI.UseVisualStyleBackColor = true;
            this.cbRightDI.Click += new System.EventHandler(this.cbDI_CheckedChanged);
            // 
            // cbAllDI
            // 
            this.cbAllDI.AutoSize = true;
            this.cbAllDI.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAllDI.Location = new System.Drawing.Point(12, 116);
            this.cbAllDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbAllDI.Name = "cbAllDI";
            this.cbAllDI.Size = new System.Drawing.Size(46, 24);
            this.cbAllDI.TabIndex = 6;
            this.cbAllDI.Text = "All";
            this.cbAllDI.UseVisualStyleBackColor = true;
            this.cbAllDI.CheckedChanged += new System.EventHandler(this.cbAll_CheckedChanged);
            // 
            // lblCombos
            // 
            this.lblCombos.AutoSize = true;
            this.lblCombos.Font = new System.Drawing.Font("Segoe UI Semibold", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCombos.Location = new System.Drawing.Point(423, 20);
            this.lblCombos.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCombos.Name = "lblCombos";
            this.lblCombos.Size = new System.Drawing.Size(94, 30);
            this.lblCombos.TabIndex = 13;
            this.lblCombos.Text = "Combos";
            // 
            // lblPercentDisplay
            // 
            this.lblPercentDisplay.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPercentDisplay.AutoSize = true;
            this.lblPercentDisplay.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPercentDisplay.Location = new System.Drawing.Point(8, 30);
            this.lblPercentDisplay.Name = "lblPercentDisplay";
            this.lblPercentDisplay.Size = new System.Drawing.Size(45, 20);
            this.lblPercentDisplay.TabIndex = 12;
            this.lblPercentDisplay.Text = "100%";
            // 
            // btnAddCombo
            // 
            this.btnAddCombo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddCombo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAddCombo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCombo.Location = new System.Drawing.Point(791, 113);
            this.btnAddCombo.Margin = new System.Windows.Forms.Padding(2);
            this.btnAddCombo.Name = "btnAddCombo";
            this.btnAddCombo.Size = new System.Drawing.Size(115, 27);
            this.btnAddCombo.TabIndex = 3;
            this.btnAddCombo.Text = "Add";
            this.btnAddCombo.UseVisualStyleBackColor = false;
            this.btnAddCombo.Click += new System.EventHandler(this.btnAddCombo_Click);
            // 
            // lblCharacterName
            // 
            this.lblCharacterName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCharacterName.AutoSize = true;
            this.lblCharacterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblCharacterName.Location = new System.Drawing.Point(747, 23);
            this.lblCharacterName.Name = "lblCharacterName";
            this.lblCharacterName.Size = new System.Drawing.Size(163, 20);
            this.lblCharacterName.TabIndex = 19;
            this.lblCharacterName.Text = "Opponent: Zetterburn";
            // 
            // gridCombos
            // 
            this.gridCombos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridCombos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridCombos.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridCombos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gridCombos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridCombos.DefaultCellStyle = dataGridViewCellStyle2;
            this.gridCombos.Location = new System.Drawing.Point(12, 146);
            this.gridCombos.Name = "gridCombos";
            this.gridCombos.RowHeadersVisible = false;
            this.gridCombos.RowHeadersWidth = 51;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gridCombos.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.gridCombos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridCombos.Size = new System.Drawing.Size(894, 207);
            this.gridCombos.TabIndex = 4;
            this.gridCombos.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridCombos_CellDoubleClick);
            // 
            // btnGoBack
            // 
            this.btnGoBack.BackColor = System.Drawing.SystemColors.Control;
            this.btnGoBack.FlatAppearance.BorderSize = 0;
            this.btnGoBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGoBack.Location = new System.Drawing.Point(0, 0);
            this.btnGoBack.Name = "btnGoBack";
            this.btnGoBack.Size = new System.Drawing.Size(60, 24);
            this.btnGoBack.TabIndex = 20;
            this.btnGoBack.Text = "Go Back";
            this.btnGoBack.UseVisualStyleBackColor = false;
            this.btnGoBack.Click += new System.EventHandler(this.btnGoBack_Click);
            // 
            // cbAllPercents
            // 
            this.cbAllPercents.AutoSize = true;
            this.cbAllPercents.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.cbAllPercents.Location = new System.Drawing.Point(682, 116);
            this.cbAllPercents.Name = "cbAllPercents";
            this.cbAllPercents.Size = new System.Drawing.Size(104, 24);
            this.cbAllPercents.TabIndex = 21;
            this.cbAllPercents.Text = "All Percents";
            this.cbAllPercents.UseVisualStyleBackColor = true;
            this.cbAllPercents.CheckedChanged += new System.EventHandler(this.cbAllPercents_CheckedChanged);
            // 
            // MatchupChart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 365);
            this.Controls.Add(this.cbAllPercents);
            this.Controls.Add(this.btnGoBack);
            this.Controls.Add(this.lblCharacterName);
            this.Controls.Add(this.gridCombos);
            this.Controls.Add(this.btnAddCombo);
            this.Controls.Add(this.cbNoneDI);
            this.Controls.Add(this.cbUpDI);
            this.Controls.Add(this.lblPercentDisplay);
            this.Controls.Add(this.cbAllDI);
            this.Controls.Add(this.lblCombos);
            this.Controls.Add(this.cbRightDI);
            this.Controls.Add(this.cbDownDI);
            this.Controls.Add(this.cbLeftDI);
            this.Controls.Add(this.tbPercentage);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MatchupChart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Matchup Chart";
            this.Resize += new System.EventHandler(this.MatchupChart_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.tbPercentage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridCombos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TrackBar tbPercentage;
        private System.Windows.Forms.CheckBox cbAllDI;
        private System.Windows.Forms.CheckBox cbLeftDI;
        private System.Windows.Forms.CheckBox cbRightDI;
        private System.Windows.Forms.CheckBox cbUpDI;
        private System.Windows.Forms.CheckBox cbDownDI;
        private System.Windows.Forms.Label lblCombos;
        private System.Windows.Forms.Label lblPercentDisplay;
        private System.Windows.Forms.CheckBox cbNoneDI;
        private System.Windows.Forms.Button btnAddCombo;
        private System.Windows.Forms.Label lblCharacterName;
        private System.Windows.Forms.DataGridView gridCombos;
        private System.Windows.Forms.Button btnGoBack;
        private System.Windows.Forms.CheckBox cbAllPercents;
    }
}