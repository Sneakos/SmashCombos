﻿namespace SmashCombos
{
    partial class MatchupChartAttributes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MatchupChart));
            this.tbPercentage = new System.Windows.Forms.TrackBar();
            this.gridCombos = new System.Windows.Forms.DataGridView();
            this.cbNoneDI = new System.Windows.Forms.CheckBox();
            this.cbUpDI = new System.Windows.Forms.CheckBox();
            this.cbDownDI = new System.Windows.Forms.CheckBox();
            this.cbLeftDI = new System.Windows.Forms.CheckBox();
            this.cbRightDI = new System.Windows.Forms.CheckBox();
            this.cbAllDI = new System.Windows.Forms.CheckBox();
            this.lblPercent = new System.Windows.Forms.Label();
            this.lblPercentDisplay = new System.Windows.Forms.Label();
            this.gridAttributes = new System.Windows.Forms.DataGridView();
            this.btnAddCombo = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.colShieldGrab = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOOS3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOOS2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOOS1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridOOS = new System.Windows.Forms.DataGridView();
            this.lblOOS = new System.Windows.Forms.Label();
            this.lblCharacterName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tbPercentage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridCombos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridAttributes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridOOS)).BeginInit();
            this.SuspendLayout();
            // 
            // tbPercentage
            // 
            this.tbPercentage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbPercentage.BackColor = System.Drawing.Color.White;
            this.tbPercentage.Location = new System.Drawing.Point(4, 319);
            this.tbPercentage.Margin = new System.Windows.Forms.Padding(2);
            this.tbPercentage.Maximum = 150;
            this.tbPercentage.Name = "tbPercentage";
            this.tbPercentage.Size = new System.Drawing.Size(903, 45);
            this.tbPercentage.TabIndex = 2;
            this.tbPercentage.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbPercentage.ValueChanged += new System.EventHandler(this.tbPercentage_ValueChanged);
            // 
            // gridCombos
            // 
            this.gridCombos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridCombos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridCombos.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridCombos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gridCombos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridCombos.DefaultCellStyle = dataGridViewCellStyle2;
            this.gridCombos.Location = new System.Drawing.Point(4, 416);
            this.gridCombos.Name = "gridCombos";
            this.gridCombos.RowHeadersVisible = false;
            this.gridCombos.RowHeadersWidth = 51;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gridCombos.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.gridCombos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridCombos.Size = new System.Drawing.Size(903, 265);
            this.gridCombos.TabIndex = 4;
            this.gridCombos.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridCombos_CellDoubleClick);
            // 
            // cbNoneDI
            // 
            this.cbNoneDI.AutoSize = true;
            this.cbNoneDI.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.cbNoneDI.Location = new System.Drawing.Point(394, 382);
            this.cbNoneDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbNoneDI.Name = "cbNoneDI";
            this.cbNoneDI.Size = new System.Drawing.Size(67, 24);
            this.cbNoneDI.TabIndex = 11;
            this.cbNoneDI.Text = "No DI";
            this.cbNoneDI.UseVisualStyleBackColor = true;
            this.cbNoneDI.CheckedChanged += new System.EventHandler(this.cbDI_CheckedChanged);
            // 
            // cbUpDI
            // 
            this.cbUpDI.AutoSize = true;
            this.cbUpDI.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.cbUpDI.Location = new System.Drawing.Point(321, 382);
            this.cbUpDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbUpDI.Name = "cbUpDI";
            this.cbUpDI.Size = new System.Drawing.Size(66, 24);
            this.cbUpDI.TabIndex = 7;
            this.cbUpDI.Text = "Up DI";
            this.cbUpDI.UseVisualStyleBackColor = true;
            this.cbUpDI.Click += new System.EventHandler(this.cbDI_CheckedChanged);
            // 
            // cbDownDI
            // 
            this.cbDownDI.AutoSize = true;
            this.cbDownDI.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.cbDownDI.Location = new System.Drawing.Point(230, 382);
            this.cbDownDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbDownDI.Name = "cbDownDI";
            this.cbDownDI.Size = new System.Drawing.Size(86, 24);
            this.cbDownDI.TabIndex = 8;
            this.cbDownDI.Text = "Down DI";
            this.cbDownDI.UseVisualStyleBackColor = true;
            this.cbDownDI.Click += new System.EventHandler(this.cbDI_CheckedChanged);
            // 
            // cbLeftDI
            // 
            this.cbLeftDI.AutoSize = true;
            this.cbLeftDI.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.cbLeftDI.Location = new System.Drawing.Point(146, 382);
            this.cbLeftDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbLeftDI.Name = "cbLeftDI";
            this.cbLeftDI.Size = new System.Drawing.Size(72, 24);
            this.cbLeftDI.TabIndex = 9;
            this.cbLeftDI.Text = "Left DI";
            this.cbLeftDI.UseVisualStyleBackColor = true;
            this.cbLeftDI.Click += new System.EventHandler(this.cbDI_CheckedChanged);
            // 
            // cbRightDI
            // 
            this.cbRightDI.AutoSize = true;
            this.cbRightDI.Font = new System.Drawing.Font("Segoe UI", 10.8F);
            this.cbRightDI.Location = new System.Drawing.Point(58, 382);
            this.cbRightDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbRightDI.Name = "cbRightDI";
            this.cbRightDI.Size = new System.Drawing.Size(82, 24);
            this.cbRightDI.TabIndex = 10;
            this.cbRightDI.Text = "Right DI";
            this.cbRightDI.UseVisualStyleBackColor = true;
            this.cbRightDI.Click += new System.EventHandler(this.cbDI_CheckedChanged);
            // 
            // cbAllDI
            // 
            this.cbAllDI.AutoSize = true;
            this.cbAllDI.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAllDI.Location = new System.Drawing.Point(4, 382);
            this.cbAllDI.Margin = new System.Windows.Forms.Padding(2);
            this.cbAllDI.Name = "cbAllDI";
            this.cbAllDI.Size = new System.Drawing.Size(46, 24);
            this.cbAllDI.TabIndex = 6;
            this.cbAllDI.Text = "All";
            this.cbAllDI.UseVisualStyleBackColor = true;
            this.cbAllDI.CheckedChanged += new System.EventHandler(this.cbAll_CheckedChanged);
            // 
            // lblPercent
            // 
            this.lblPercent.AutoSize = true;
            this.lblPercent.Font = new System.Drawing.Font("Segoe UI Semibold", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPercent.Location = new System.Drawing.Point(7, 245);
            this.lblPercent.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(94, 30);
            this.lblPercent.TabIndex = 13;
            this.lblPercent.Text = "Combos";
            // 
            // lblPercentDisplay
            // 
            this.lblPercentDisplay.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPercentDisplay.AutoSize = true;
            this.lblPercentDisplay.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPercentDisplay.Location = new System.Drawing.Point(8, 291);
            this.lblPercentDisplay.Name = "lblPercentDisplay";
            this.lblPercentDisplay.Size = new System.Drawing.Size(45, 20);
            this.lblPercentDisplay.TabIndex = 12;
            this.lblPercentDisplay.Text = "100%";
            // 
            // gridAttributes
            // 
            this.gridAttributes.AllowUserToAddRows = false;
            this.gridAttributes.AllowUserToDeleteRows = false;
            this.gridAttributes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridAttributes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridAttributes.BackgroundColor = System.Drawing.SystemColors.Control;
            this.gridAttributes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridAttributes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.gridAttributes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridAttributes.DefaultCellStyle = dataGridViewCellStyle5;
            this.gridAttributes.Location = new System.Drawing.Point(9, 49);
            this.gridAttributes.Margin = new System.Windows.Forms.Padding(2);
            this.gridAttributes.Name = "gridAttributes";
            this.gridAttributes.RowHeadersVisible = false;
            this.gridAttributes.RowHeadersWidth = 51;
            this.gridAttributes.RowTemplate.Height = 24;
            this.gridAttributes.Size = new System.Drawing.Size(904, 79);
            this.gridAttributes.TabIndex = 15;
            // 
            // btnAddCombo
            // 
            this.btnAddCombo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddCombo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAddCombo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCombo.Location = new System.Drawing.Point(783, 380);
            this.btnAddCombo.Margin = new System.Windows.Forms.Padding(2);
            this.btnAddCombo.Name = "btnAddCombo";
            this.btnAddCombo.Size = new System.Drawing.Size(124, 27);
            this.btnAddCombo.TabIndex = 3;
            this.btnAddCombo.Text = "Add";
            this.btnAddCombo.UseVisualStyleBackColor = false;
            this.btnAddCombo.Click += new System.EventHandler(this.btnAddCombo_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(235, 30);
            this.label1.TabIndex = 18;
            this.label1.Text = "Opponent\'s Attributes";
            // 
            // colShieldGrab
            // 
            this.colShieldGrab.HeaderText = "Shield Grab";
            this.colShieldGrab.Name = "colShieldGrab";
            // 
            // colOOS3
            // 
            this.colOOS3.HeaderText = "Option3";
            this.colOOS3.Name = "colOOS3";
            // 
            // colOOS2
            // 
            this.colOOS2.HeaderText = "Option2";
            this.colOOS2.Name = "colOOS2";
            // 
            // colOOS1
            // 
            this.colOOS1.HeaderText = "Option1";
            this.colOOS1.Name = "colOOS1";
            // 
            // gridOOS
            // 
            this.gridOOS.AllowUserToAddRows = false;
            this.gridOOS.AllowUserToDeleteRows = false;
            this.gridOOS.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridOOS.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridOOS.BackgroundColor = System.Drawing.SystemColors.Control;
            this.gridOOS.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridOOS.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.gridOOS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridOOS.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colOOS1,
            this.colOOS2,
            this.colOOS3,
            this.colShieldGrab});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridOOS.DefaultCellStyle = dataGridViewCellStyle7;
            this.gridOOS.Location = new System.Drawing.Point(9, 175);
            this.gridOOS.Margin = new System.Windows.Forms.Padding(2);
            this.gridOOS.Name = "gridOOS";
            this.gridOOS.RowHeadersVisible = false;
            this.gridOOS.RowHeadersWidth = 51;
            this.gridOOS.RowTemplate.Height = 24;
            this.gridOOS.Size = new System.Drawing.Size(904, 68);
            this.gridOOS.TabIndex = 16;
            // 
            // lblOOS
            // 
            this.lblOOS.AutoSize = true;
            this.lblOOS.Font = new System.Drawing.Font("Segoe UI Semibold", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOOS.Location = new System.Drawing.Point(7, 135);
            this.lblOOS.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOOS.Name = "lblOOS";
            this.lblOOS.Size = new System.Drawing.Size(266, 30);
            this.lblOOS.TabIndex = 17;
            this.lblOOS.Text = "Opponent\'s OOS Options";
            // 
            // lblCharacterName
            // 
            this.lblCharacterName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCharacterName.AutoSize = true;
            this.lblCharacterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.lblCharacterName.Location = new System.Drawing.Point(745, 9);
            this.lblCharacterName.Name = "lblCharacterName";
            this.lblCharacterName.Size = new System.Drawing.Size(84, 18);
            this.lblCharacterName.TabIndex = 19;
            this.lblCharacterName.Text = "Playing As: ";
            // 
            // MatchupChart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 689);
            this.Controls.Add(this.lblCharacterName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblOOS);
            this.Controls.Add(this.gridOOS);
            this.Controls.Add(this.gridCombos);
            this.Controls.Add(this.btnAddCombo);
            this.Controls.Add(this.gridAttributes);
            this.Controls.Add(this.cbNoneDI);
            this.Controls.Add(this.cbUpDI);
            this.Controls.Add(this.lblPercentDisplay);
            this.Controls.Add(this.cbAllDI);
            this.Controls.Add(this.lblPercent);
            this.Controls.Add(this.cbRightDI);
            this.Controls.Add(this.cbDownDI);
            this.Controls.Add(this.cbLeftDI);
            this.Controls.Add(this.tbPercentage);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MatchupChart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Matchup Chart";
            ((System.ComponentModel.ISupportInitialize)(this.tbPercentage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridCombos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridAttributes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridOOS)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TrackBar tbPercentage;
        private System.Windows.Forms.CheckBox cbAllDI;
        private System.Windows.Forms.CheckBox cbLeftDI;
        private System.Windows.Forms.CheckBox cbRightDI;
        private System.Windows.Forms.CheckBox cbUpDI;
        private System.Windows.Forms.CheckBox cbDownDI;
        private System.Windows.Forms.Label lblPercent;
        private System.Windows.Forms.Label lblPercentDisplay;
        private System.Windows.Forms.DataGridView gridCombos;
        private System.Windows.Forms.CheckBox cbNoneDI;
        private System.Windows.Forms.DataGridView gridAttributes;
        private System.Windows.Forms.Button btnAddCombo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colShieldGrab;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOOS3;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOOS2;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOOS1;
        private System.Windows.Forms.DataGridView gridOOS;
        private System.Windows.Forms.Label lblOOS;
        private System.Windows.Forms.Label lblCharacterName;
    }
}