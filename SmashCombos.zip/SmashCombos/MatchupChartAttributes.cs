﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security;
using System.Windows.Forms;

namespace SmashCombos
{
    public partial class MatchupChartAttributes : Form
    {
        private Character _playingAs;
        private Character _opponent;
        private Root _parent;

        public MatchupChartAttributes(Root parent, Character playingAs, Character opponent)
        {
            InitializeComponent();

            _opponent = opponent;
            _playingAs = playingAs;
            _parent = parent;

            Setup();
        }

        private void Setup()
        {
            ComponentResourceManager resources = new ComponentResourceManager(typeof(MatchupChart));
            Text = _opponent.Name;

            string file = HelperMethods.Path + @"\Assets\Images\Characters\" + _parent.SmashGame + @"\" + _opponent.Name + ".png";
            Image img = Image.FromFile(file);

            Icon = HelperMethods.IconFromImage(img);

            gridCombos.Font = new Font("Segoe UI Semibold", 10, FontStyle.Regular);

            lblCharacterName.Text = "Playing as: " + _playingAs.Name;

            LoadCharacterCombos();

            SetupComboGrid();

            //SetupAttributesGrid();

            lblPercentDisplay.Text = tbPercentage.Value.ToString() + "%";
        }

        private void SetupAttributesGrid()
        {
            gridAttributes.DataSource = new List<CharacterAttributes> { _opponent.Attributes };

            gridAttributes.Columns["OOS1"].Visible = false;
            gridAttributes.Columns["OOS2"].Visible = false;
            gridAttributes.Columns["OOS3"].Visible = false;
            gridAttributes.Columns["ShieldGrab"].Visible = false;

            gridAttributes.Columns["WalkSpeed"].HeaderText = "Walk Speed";
            gridAttributes.Columns["RunSpeed"].HeaderText = "Run Speed";
            gridAttributes.Columns["InitialDash"].HeaderText = "Dash Speed";
            gridAttributes.Columns["AirSpeed"].HeaderText = "Air Speed";
            gridAttributes.Columns["FallSpeed"].HeaderText = "Fall Speed";
            gridAttributes.Columns["FastFallSpeed"].HeaderText = "Fast Fall Speed";

            SetupOOS();
        }

        private void SetupOOS()
        {
            colOOS1.HeaderText = HelperMethods.GetMoveTitle(_opponent.Attributes.OOS1.Item1);
            colOOS2.HeaderText = HelperMethods.GetMoveTitle(_opponent.Attributes.OOS2.Item1);
            colOOS3.HeaderText = HelperMethods.GetMoveTitle(_opponent.Attributes.OOS3.Item1);

            gridOOS.Rows.Add(_opponent.Attributes.OOS1.Item2 + " Frames", 
                             _opponent.Attributes.OOS2.Item2 + " Frames",
                             _opponent.Attributes.OOS3.Item2 + " Frames", 
                             _opponent.Attributes.ShieldGrab + " Frames");
        }

        private void SetupComboGrid()
        {
            var result = _opponent.Combos.Select(c => new
            {
                c.LowPercent,
                c.HighPercent,
                Combo = GetComboString(c.Moves),
                c.Note,
                c.DIs
            })
                .Where(c => tbPercentage.Value  >=c.LowPercent && tbPercentage.Value <= c.HighPercent)
                .Where(c => DIExists(c.DIs))
                .ToList();

            gridCombos.DataSource = result;

            gridCombos.Columns["HighPercent"].HeaderText = "Max Percent";
            gridCombos.Columns["HighPercent"].DefaultCellStyle.Format = "0\\%";
            gridCombos.Columns["LowPercent"].HeaderText = "Min Percent";
            gridCombos.Columns["LowPercent"].DefaultCellStyle.Format = "0\\%";
        }

        private void LoadCharacterCombos()
        {
            string file = HelperMethods.Path + @"\Assets\Data\Characters\" + _parent.SmashGame + @"\" + _playingAs.Name + ".txt";

            string[] lines = File.ReadAllLines(file);

            foreach (string line in lines)
            {
                if( line.StartsWith(_opponent.Name) )
                {
                    _opponent.Combos = JsonConvert.DeserializeObject<List<Combo>>((line.Split('|')[1]));
                    return;
                }
            }
        }

        private void cbDI_CheckedChanged(object sender, EventArgs e)
        {
            SetupComboGrid();
        }

        private bool DIExists(DI[] dis)
        {
            if (cbLeftDI.Checked)
                if (!dis.Contains(DI.Left))
                    return false;
            if (cbRightDI.Checked)
                if (!dis.Contains(DI.Right))
                    return false;
            if (cbUpDI.Checked)
                if (!dis.Contains(DI.Up))
                    return false;
            if (cbDownDI.Checked)
                if (!dis.Contains(DI.Down))
                    return false;
            if (cbNoneDI.Checked)
                if (!dis.Contains(DI.None))
                    return false;

            return true;
        }

        private void tbPercentage_ValueChanged(object sender, EventArgs e)
        {
            SetupComboGrid();

            lblPercentDisplay.Text = tbPercentage.Value.ToString() + "%";
        }

        private void cbAll_CheckedChanged(object sender, EventArgs e)
        {
            if (cbAllDI.Checked)
            {
                cbUpDI.CheckedChanged -= cbDI_CheckedChanged;
                cbDownDI.CheckedChanged -= cbDI_CheckedChanged;
                cbRightDI.CheckedChanged -= cbDI_CheckedChanged;
                cbLeftDI.CheckedChanged -= cbDI_CheckedChanged;


                cbUpDI.Checked = true;
                cbDownDI.Checked = true;
                cbLeftDI.Checked = true;
                cbRightDI.Checked = true;

                cbUpDI.CheckedChanged += cbDI_CheckedChanged;
                cbDownDI.CheckedChanged += cbDI_CheckedChanged;
                cbRightDI.CheckedChanged += cbDI_CheckedChanged;
                cbLeftDI.CheckedChanged += cbDI_CheckedChanged;

                SetupComboGrid();
            }
        }

        private void cmbPokemon_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetupComboGrid();
        }

        public string GetComboString(ComboMoves[] moves)
        {
            int lastIndex = moves.Length - 1;

            if (lastIndex < 0)
            {
                return "";
            }

            string ret = "";

            for (int i = 0; i < lastIndex; i++)
            {
                ComboMoves move = moves[i];
                ret += HelperMethods.GetMoveTitle(move) + " -> ";
            }

            ret += HelperMethods.GetMoveTitle(moves[lastIndex]);

            return ret;
        }

        private void btnAddCombo_Click(object sender, EventArgs e)
        {
            AddCombo addCombo = new AddCombo(_opponent.Name);

            if (addCombo.ShowDialog() == DialogResult.OK)
            {
                _opponent.Combos.Add(new Combo
                {
                    Moves = addCombo.Moves.ToArray(),
                    DIs = addCombo.ValidDI.ToArray(),
                    HighPercent = addCombo.MaxPercent,
                    LowPercent = addCombo.MinPercent,
                    Note = addCombo.Note
                });
            }

            Save();
            SetupComboGrid();
        }

        private void gridCombos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (gridCombos.SelectedRows.Count != 1)
                return;

            DataGridViewRow row = gridCombos.SelectedRows[0];

            int index = row.Index;

            Combo combo = _opponent.Combos[index];

            AddCombo addCombo = new AddCombo(combo.Moves.ToList(), _opponent.Name, combo.LowPercent, combo.HighPercent, combo.DIs.ToList(), combo.Note);

            DialogResult dialogResult = addCombo.ShowDialog();

            if (dialogResult == DialogResult.OK)
            {
                _opponent.Combos[index] = new Combo
                {
                    Moves = addCombo.Moves.ToArray(),
                    DIs = addCombo.ValidDI.ToArray(),
                    HighPercent = addCombo.MaxPercent,
                    LowPercent = addCombo.MinPercent,
                    Note = addCombo.Note
                };
            }
            else if (dialogResult == DialogResult.No)
            {
                _opponent.Combos.RemoveAt(index);
            }

            Save();
            SetupComboGrid();
        }

        private void Save()
        {
            _parent.Save(_playingAs, _opponent);
        }
    }
}
