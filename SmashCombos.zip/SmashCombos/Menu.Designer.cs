﻿namespace SmashCombos
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.btnMelee = new System.Windows.Forms.Button();
            this.btnUltimate = new System.Windows.Forms.Button();
            this.btnRivals = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMelee
            // 
            this.btnMelee.BackColor = System.Drawing.Color.Red;
            this.btnMelee.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMelee.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnMelee.Location = new System.Drawing.Point(12, 15);
            this.btnMelee.Name = "btnMelee";
            this.btnMelee.Size = new System.Drawing.Size(245, 68);
            this.btnMelee.TabIndex = 0;
            this.btnMelee.Text = "Melee";
            this.btnMelee.UseVisualStyleBackColor = false;
            this.btnMelee.Click += new System.EventHandler(this.btnMelee_Click);
            // 
            // btnUltimate
            // 
            this.btnUltimate.BackColor = System.Drawing.Color.Blue;
            this.btnUltimate.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUltimate.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnUltimate.Location = new System.Drawing.Point(12, 89);
            this.btnUltimate.Name = "btnUltimate";
            this.btnUltimate.Size = new System.Drawing.Size(245, 68);
            this.btnUltimate.TabIndex = 1;
            this.btnUltimate.Text = "Ultimate";
            this.btnUltimate.UseVisualStyleBackColor = false;
            this.btnUltimate.Click += new System.EventHandler(this.btnUltimate_Click);
            // 
            // btnRivals
            // 
            this.btnRivals.BackColor = System.Drawing.Color.Purple;
            this.btnRivals.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRivals.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnRivals.Location = new System.Drawing.Point(12, 163);
            this.btnRivals.Name = "btnRivals";
            this.btnRivals.Size = new System.Drawing.Size(245, 68);
            this.btnRivals.TabIndex = 2;
            this.btnRivals.Text = "Rivals";
            this.btnRivals.UseVisualStyleBackColor = false;
            this.btnRivals.Click += new System.EventHandler(this.btnRivals_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(269, 243);
            this.Controls.Add(this.btnRivals);
            this.Controls.Add(this.btnUltimate);
            this.Controls.Add(this.btnMelee);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Choose a game";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMelee;
        private System.Windows.Forms.Button btnUltimate;
        private System.Windows.Forms.Button btnRivals;
    }
}