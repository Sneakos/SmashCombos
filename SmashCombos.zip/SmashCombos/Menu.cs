﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmashCombos
{
    public partial class Menu : Form
    {
        public Menu()
        {
            double num = 1024.34;

            string tmp = num.ToString();

            InitializeComponent();
        }

        private void btnMelee_Click(object sender, EventArgs e)
        {
            Root root = new Root(Game.Melee, null);

            Hide();

            if (root.ShowDialog() == DialogResult.OK)
            {
                Show();
            }
            else
            {
                Close();
            }
        }

        private void btnUltimate_Click(object sender, EventArgs e)
        {
            Root root = new Root(Game.Ultimate, null);

            Hide();

            if (root.ShowDialog() == DialogResult.OK)
            {
                Show();
            }
            else
            {
                Close();
            }
        }

        private void btnRivals_Click(object sender, EventArgs e)
        {
            Root root = new Root(Game.Rivals, null);

            Hide();

            if (root.ShowDialog() == DialogResult.OK)
            {
                Show();
            }
            else
            {
                Close();
            }
        }
    }
}
