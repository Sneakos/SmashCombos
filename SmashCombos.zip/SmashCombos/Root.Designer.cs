﻿namespace SmashCombos
{
    partial class Root
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Root));
            this.btnTemplate = new System.Windows.Forms.Button();
            this.lblTemplate = new System.Windows.Forms.Label();
            this.pnlTemplate = new System.Windows.Forms.Panel();
            this.lblChoose = new System.Windows.Forms.Label();
            this.btnGoBack = new System.Windows.Forms.Button();
            this.ttGoBack = new System.Windows.Forms.ToolTip(this.components);
            this.pnlTemplate.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnTemplate
            // 
            this.btnTemplate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTemplate.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnTemplate.Location = new System.Drawing.Point(0, 0);
            this.btnTemplate.Margin = new System.Windows.Forms.Padding(2);
            this.btnTemplate.Name = "btnTemplate";
            this.btnTemplate.Size = new System.Drawing.Size(75, 81);
            this.btnTemplate.TabIndex = 0;
            this.btnTemplate.Tag = "Template";
            this.btnTemplate.UseVisualStyleBackColor = true;
            this.btnTemplate.Click += new System.EventHandler(this.btnCharacter_Click);
            // 
            // lblTemplate
            // 
            this.lblTemplate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTemplate.Location = new System.Drawing.Point(1, 84);
            this.lblTemplate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTemplate.Name = "lblTemplate";
            this.lblTemplate.Size = new System.Drawing.Size(74, 19);
            this.lblTemplate.TabIndex = 1;
            this.lblTemplate.Text = "Name";
            this.lblTemplate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlTemplate
            // 
            this.pnlTemplate.Controls.Add(this.btnTemplate);
            this.pnlTemplate.Controls.Add(this.lblTemplate);
            this.pnlTemplate.Location = new System.Drawing.Point(11, 69);
            this.pnlTemplate.Margin = new System.Windows.Forms.Padding(2);
            this.pnlTemplate.Name = "pnlTemplate";
            this.pnlTemplate.Size = new System.Drawing.Size(76, 109);
            this.pnlTemplate.TabIndex = 3;
            // 
            // lblChoose
            // 
            this.lblChoose.AutoSize = true;
            this.lblChoose.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChoose.Location = new System.Drawing.Point(172, 9);
            this.lblChoose.Name = "lblChoose";
            this.lblChoose.Size = new System.Drawing.Size(380, 39);
            this.lblChoose.TabIndex = 4;
            this.lblChoose.Text = "Choose Your Character";
            // 
            // btnGoBack
            // 
            this.btnGoBack.BackColor = System.Drawing.SystemColors.Control;
            this.btnGoBack.FlatAppearance.BorderSize = 0;
            this.btnGoBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGoBack.Location = new System.Drawing.Point(0, 0);
            this.btnGoBack.Name = "btnGoBack";
            this.btnGoBack.Size = new System.Drawing.Size(60, 24);
            this.btnGoBack.TabIndex = 5;
            this.btnGoBack.Text = "Go Back";
            this.ttGoBack.SetToolTip(this.btnGoBack, "Go Back");
            this.btnGoBack.UseVisualStyleBackColor = false;
            this.btnGoBack.Click += new System.EventHandler(this.btnGoBack_Click);
            // 
            // Root
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(730, 461);
            this.Controls.Add(this.btnGoBack);
            this.Controls.Add(this.lblChoose);
            this.Controls.Add(this.pnlTemplate);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Root";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = "";
            this.Text = "Melee";
            this.SizeChanged += new System.EventHandler(this.Root_SizeChanged);
            this.pnlTemplate.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTemplate;
        private System.Windows.Forms.Label lblTemplate;
        private System.Windows.Forms.Panel pnlTemplate;
        private System.Windows.Forms.Label lblChoose;
        private System.Windows.Forms.Button btnGoBack;
        private System.Windows.Forms.ToolTip ttGoBack;
    }
}

