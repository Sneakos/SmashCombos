﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmashCombos
{
    public partial class Root : Form
    {
        private Point[,] _points;
        private Character[] _characters;
        private Character _playingAs;

        public Game SmashGame { get; set; }

        public Root(Game game, Character playingAs)
        {
            InitializeComponent();

            if (playingAs == null)
                lblChoose.Text = "Choose your character";
            else
                lblChoose.Text = "Choose your opponent";

            Text = game.ToString();

            lblChoose.AlignLabelToScreenHorizontally(HorizontalAlignment.Center);

            SmashGame = game;
            _playingAs = playingAs;

            CreateCharacter();

            Setup();
        }

        private void Setup()
        {
            _characters = GetCharacters();

            int perRow = Width / (btnTemplate.Width + 15);
            int maxRows = 50;

            int currX = pnlTemplate.Location.X;
            int currY = pnlTemplate.Location.Y;

            _points = new Point[perRow, maxRows];

            for (int i = 0; i < perRow; i++)
            {
                for (int j = 0; j < maxRows; j++)
                {
                    _points[i, j] = new Point(currX, currY);

                    currX += btnTemplate.Width + 15;
                }
                currY += btnTemplate.Height + 15;
            }

            int index = 0;

            foreach (Character character in _characters)
            {
                string file = HelperMethods.Path + @"\Assets\Images\Characters\" + SmashGame.ToString() + @"\" + character.Name + ".png";
                Image img = Image.FromFile(file);

                img = HelperMethods.ResizeImage(img, btnTemplate.Size);

                Button btn = new Button
                {
                    Name = "btn" + character.Name,
                    Size = btnTemplate.Size,
                    Location = new Point(0, 0),
                    Image = img
                };

                btn.Tag = character;
                btn.Click += btnCharacter_Click;

                Label lbl = new Label
                {
                    Name = "lbl" + character.Name,
                    Text = character.Name,
                    Location = new Point(1, btn.Height + 1),
                    Font = lblTemplate.Font,
                    AutoSize = false,
                    Width = lblTemplate.Width,
                    TextAlign = ContentAlignment.MiddleCenter
                };

                Panel pnl = new Panel
                {
                    Location = GetPoint(index),
                    Size = pnlTemplate.Size
                };

                pnl.Controls.Add(btn);
                pnl.Controls.Add(lbl);

                index++;

                Controls.Add(pnl);
            }

            Controls.Remove(pnlTemplate);
        }

        private Point GetPoint(int index)
        {
            int x = index / _points.GetLength(0);
            int y = index % _points.GetLength(1);

            return _points[x, y];
        }

        private Character[] GetCharacters()
        {
            string path = HelperMethods.Path + @"\Assets\Data\Characters\" + SmashGame + @"\" + "Attributes.txt";

            try
            {
                string[] lines = File.ReadAllLines(path);

                Character[] characters = new Character[lines.Length];

                for(int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i];

                    string[] parts = line.Split('|');

                    Character character = new Character { Name = parts[0] };
                    character.Attributes = ParseCharacter(parts[1]);


                    characters[i] = character;
                }

                return characters;
            }
            catch (Exception ex)
            {
                MessageBox.Show("File couldn't be opened - " + ex.Message);
                return new Character[0];
            }
        }
        private CharacterAttributes ParseCharacter(string line)
        {
            return JsonConvert.DeserializeObject<CharacterAttributes>(line);
        }

        private Character CreateCharacter()
        {
            Character character = new Character
            {
                Name = "Roy",
                Combos = new List<Combo>
                {
                    new Combo
                    {
                        DIs = new DI[]
                        {
                            DI.Left,
                            DI.Down,
                            DI.None
                        },
                        LowPercent = 0,
                        HighPercent = 10,
                        Moves = new ComboMoves[]
                        {
                            ComboMoves.Grab,
                            ComboMoves.DownThrow
                        },
                        Note = "Testing",
                    }
                },
                Attributes = new CharacterAttributes
                {
                    Weight = 95,
                    Gravity = 0.114,
                    WalkSpeed = 1.208,
                    RunSpeed = 2.145,
                    InitialDash = 2.2,
                    AirSpeed = 1.302,
                    SH = 30,
                    FH = 44,
                    SHFF = 20,
                    FHFF = 31,
                    FallSpeed = 1.8,
                    FastFallSpeed = 2.88,
                    OOS1 = new Tuple<ComboMoves, int>(ComboMoves.UpAir, 8),
                    OOS2 = new Tuple<ComboMoves, int>(ComboMoves.UpSpecial, 9),
                    OOS3 = new Tuple<ComboMoves, int>(ComboMoves.BackAir, 11),
                    ShieldGrab = 11
                }
            };

            var tmp = JsonConvert.SerializeObject(character);

            return character;
        }

        private void btnCharacter_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            Character character = (Character)button.Tag;

            if (_playingAs == null)
            {
                lblChoose.Text = "Choose your opponent";

                lblChoose.AlignLabelToScreenHorizontally(HorizontalAlignment.Center);

                _playingAs = character;

                CreateCharacter();

                Setup();
            }
            else
            {
                MatchupChart chart = new MatchupChart(this, _playingAs, character);

                Hide();

                if ( chart.ShowDialog() == DialogResult.OK)
                {
                    Show();
                }
                else
                {
                    Hide();
                }
            }
        }

        public void Save(Character playingAs, Character opponent)
        {
            string file = HelperMethods.Path + @"\Assets\Data\Characters\" + SmashGame + @"\" + playingAs.Name + ".txt";

            File.WriteAllText(file, opponent.Name + "|" + JsonConvert.SerializeObject(opponent.Combos));
        }

        private void Root_SizeChanged(object sender, EventArgs e)
        {
            lblChoose.AlignLabelToScreenHorizontally(HorizontalAlignment.Center);
        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {
            if (_playingAs == null)
            {
                DialogResult = DialogResult.OK;
            }
            else
            {
                lblChoose.Text = "Choose your character";

                lblChoose.AlignLabelToScreenHorizontally(HorizontalAlignment.Center);

                _playingAs = null;

                CreateCharacter();

                Setup();
            }
        }
    }
}